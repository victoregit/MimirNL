# Proposta integrada de evolução e caching do Mimir NL v0.3

Entrega documental Task125 — 2026-10-28. Complementa o programa EF-00–07; não substitui seu registro operacional, não altera o plano e não autoriza implementação ou execução. Fonte única de evidência sobre a implementação: [Programa de eficiência v0.3](docs/benchmarks/v03/plano-eficiencia.md), lido integralmente. Referências secundárias nele citadas não foram consultadas. Conhecimento técnico geral aparece como inferência ou hipótese, nunca como descoberta no código.

## 1. Resumo executivo

**Confirmado pelo relatório:** o fechamento105/120 é `technical_complete` no escopo aprovado111, enquanto eficiência continua aberta e publicação está adiada. A aprovação técnica não demonstra economia, nem aprova código futuro. A fonte é um registro da Task123 e ainda menciona revisão124 pendente; esta proposta não atualiza retrospectivamente esse estado. [Decisão e escopo](docs/benchmarks/v03/plano-eficiencia.md#decisão-e-escopo).

A direção recomendada é esclarecer o custo do contexto e sua sobreposição antes de acrescentar mecanismos. As primeiras três ações de maior retorno potencial, sem ganho garantido, são: **EF-01/T125-01**, decompor bytes e tempo; **EF-02/T125-02**, testar redundância com a base; e, se confirmada, **EF-03/T125-03**, avaliar dedupe contra a base e o uso de compact-v1 em comparações separadas. Se não houver redundância removível, encerrar essa hipótese e avaliar EF-04, sem forçar EF-03.

**Inferência técnica:** menor envelope útil pode reduzir entrada quando substitui conteúdo efetivamente enviado, mas esse efeito depende da montagem do host. Cache de recuperação pode economizar trabalho local; não garante menos tokens ou menor latência do host. **Hipótese para validação:** repetição e custo local podem eventualmente justificar um cache exato pequeno. A decisão presente é **não adicionar cache agora**: medir primeiro e manter cache semântico adiado em EF-07. Não há P0 crítico comprovado nesta fonte; P0 no plano ordena diagnóstico, não indica vulnerabilidade.

## 2. Pontos fortes da arquitetura atual

**Confirmado pelo relatório:** existem dedupe por hash entre memórias recuperadas antes de `limit`, proveniência de duplicatas, desempate de recência controlado, política opcional balanced-v1 com cobertura lexical, razões de abstenção, hard budget de bytes do envelope e compact-v1 que preserva conteúdo/proveniência. Legacy permanece padrão e telemetria é local opt-in. Esses componentes oferecem pontos de partida para experimentos delimitados, sem reconstruir a arquitetura. [Diagnóstico a resolver primeiro](docs/benchmarks/v03/plano-eficiencia.md#diagnóstico-a-resolver-primeiro).

A disciplina de comparação também é um ativo: baseline forte, pools equivalentes, separação dev/evaluation, custo de setup e gates de qualidade estão previstos. Os resultados históricos preservam aprovação factual em seus recortes, sem evidência de benefício universal. A fonte não permite descrever armazenamento completo, interfaces de extensão, cache interno, isolamento efetivo ou arquitetura de implantação. Esses aspectos permanecem desconhecidos. [Comparação futura](docs/benchmarks/v03/plano-eficiencia.md#comparação-futura-mesmo-problema-e-acesso-equivalente).

## 3. Problemas e limitações identificados

**Confirmado pelo relatório:** Codex apresentou redução de 30,33% na razão das medianas de total ao substituir seis fontes integrais por seleção; Antigravity apresentou 39,58% em contador nativo explícito, com semântica geral não confirmada. Já a avaliação de 54 chamadas manteve a base e acrescentou recuperação: input passou de 261.437 para 269.101, aumento de 7.664, ou 2,93%, em 18 posições por braço. Essas medidas usam baselines, unidades e agregações diferentes. Não demonstram regressão entre versões, economia financeira ou probabilidade de sucesso futura. [Matriz de evidências](docs/benchmarks/v03/plano-eficiencia.md#matriz-de-evidências).

**Inferência técnica:** redundância no desenho aditivo é uma explicação plausível, não uma causa estabelecida nem defeito comprovado do core. O controle C com history0 e envelope A=C não testa histórico genuíno. O baseline forte D precisa evitar validar apenas seleção contra envio integral; seu esforço humano ou busca também deve entrar no custo.

**Confirmado pelo relatório:** não houve aceleração consistente no recorte Codex; todos os pares Antigravity ficaram mais lentos; no lote54 não houve ganho robusto de latência, embora a busca média de 21,58ms já estivesse incluída. Layout v2 teve +1 input/uncached por par e nenhum cache adicional: não demonstrou benefício geral de cache. Não se pode atribuir essas diferenças a serialização, indexação ou modelo sem decomposição.

Bytes UTF-8 e estimateTokens não são tokens reais do modelo. O volume aparentemente fixo do host não autoriza subtrair um piso inferido; cache observado não identifica os trechos reutilizados. Custos financeiros, TTFT e modelo efetivo ficam desconhecidos quando não observados. Amostras pequenas e repetições não demonstram representatividade. Nenhuma porcentagem conversacional de 10–30% é evidência, meta ou previsão; a chance de ganho é desconhecida.

## 4. Oportunidades não exploradas

Aqui “não exploradas” significa **sem demonstração na fonte**, não funcionalidades comprovadamente ausentes.

- **Inferência técnica — recuperação progressiva:** começar pelo menor conjunto suficiente e expandir sob necessidade explícita pode limitar contexto. Cada expansão paga busca e montagem; só abrir após EF-04/05 se a cobertura justificar. Recuperação hierárquica exige estrutura documental confiável e medição de perdas por nível; não pressupõe grafo ou novo índice.
- **Hipótese para validação — economia contextual:** dedupe exato contra a base pode remover repetição preservando proveniência; dedupe semântico pode remover fatos distintos e exige critérios próprios. Avaliar compact-v1 existente antes de outro formato. Budget adaptativo por tarefa é hipótese EF-05, não comportamento confirmado.
- **Hipótese para validação — trabalho repetido:** medir serialização, recuperação, montagem, indexação e reprocessamento antes de otimizar. Resumos incrementais pertencem a EF-06: exigem sequência real, fonte rastreável, atualização, conflito e custo acumulado; não substituir fonte por resumo sem verificar fatos.
- **Inferência técnica — organização:** revisões, hashes, status stale, proveniência e escopo de autorização devem acompanhar decisões de reutilização. Não há evidência de escala de milhões; testes sintéticos desse porte só fariam sentido após necessidade concreta. Não recomendar rebuild, vetores ou grafo por volume hipotético.
- **Opção posterior EF-06 — exportação estruturada de conhecimento de agentes:** um contrato de ingestão poderia receber schema versionado, identidade do emissor/fonte, source hash, revisão e status inicial `candidato`. Exigiria permissão explícita, validação estrutural e de proveniência, chave idempotente por identidade/revisão, atualização/supersessão/deleção e tratamento explícito de conflitos. Conteúdo recebido permanece untrusted; instruções nele não ganham autoridade. Promoção a conhecimento validado dependeria de revisão definida. Interface existente, política de retenção e mecanismo de ingestão são desconhecidos; não se propõe implementá-los agora.

Essas opções aprofundam [EF-03–07](docs/benchmarks/v03/plano-eficiencia.md#backlog-ordenado), sem formar backlog concorrente.

## 5. Comparação de alternativas

| Decisão | Alternativas e escolha proposta | Condição para reconsiderar |
| --- | --- | --- |
| Reduzir contexto | Reutilizar compact-v1 e comparar dedupe exato contra a base separadamente; evitar formato novo ou dedupe semântico inicial | Cobertura/proveniência preservadas e redução no alvo observável |
| Evitar recuperação inútil | Avaliar balanced-v1 e abstenção existentes antes de gating novo | Positivos e negativos mostrarem oportunidade sem falsa abstenção |
| Melhorar cobertura | Budget/ranking/chunk isolados antes de progressão ou hierarquia | Falhas diagnosticadas que o método simples não resolva |
| Busca híbrida/rerank seletivo | Adiar: pode acrescentar custo, dependências e perda de cobertura; não é requisito | Falha lexical demonstrada em dev e ganho frente à alternativa determinística, incluindo custo de candidatos e rerank |
| Histórico e reutilização | EF-06 após instrumentação madura; resumo incremental só como candidato rastreável | Sequências reais demonstrarem economia acumulada sem stale/conflito |
| Arquitetura multicamadas de cache | Opção, não obrigação; nenhum cache novo neste estágio | Cada camada provar benefício isolado e combinação manter qualidade/custo |

### Estratégia de Caching Recomendada

**Estado confirmado:** a fonte reporta subset de cache do host nos experimentos, mas não descreve um cache interno do Mimir. Sua existência e compatibilidade são **desconhecidas**, não ausentes. Não há evidência suficiente para dizer que o produto precisa de uma nova camada agora. [Diagnóstico](docs/benchmarks/v03/plano-eficiencia.md#diagnóstico-a-resolver-primeiro) e [EF-06/07](docs/benchmarks/v03/plano-eficiencia.md#backlog-ordenado).

| Opção | Benefício hipotético e limite | Custo e decisão |
| --- | --- | --- |
| Retrieval Cache exato | Reutilizar seleção/montagem de consulta idêntica sob estado equivalente; poupa trabalho local repetido, sem garantir economia de input ou latência do host | RAM, lookup, validação de revisão e invalidação podem superar busca evitada. Investigar repetição em EF-01/06; MVP apenas condicional |
| Prompt Caching do host/provedor | Envelope controlado pelo Mimir com ordem determinística pode favorecer estabilidade; não demonstra prefixo LLM estável nem hit | Mimir não controla necessariamente API, layout final, cache frio ou elegibilidade. Não implica menos tokens; layout95 não mostrou ganho. Investigar apenas com observabilidade, sem encher prompt para atingir limiar |
| Semantic Cache de contexto | Reusar contexto de consultas próximas pode reduzir recuperação, mas similaridade não garante mesma necessidade, branch, revisão ou tempo | Matching, memória, validação e falsos hits acrescentam risco. Adiado EF-07 até benefício mensurável e critérios prévios de aceitação |

Semantic Cache de **contexto** devolve material recuperado para nova resposta; cache de **resposta LLM** reutilizaria resposta final e não integra esta recomendação. Nenhum deles autoriza ignorar alterações de permissão, updates ou deletes.

**MVP menor condicional:** se repetição e custo forem medidos, propor cache exato local do resultado de recuperação, sem dependência nova presumida. Reutilizar componentes existentes apenas onde confirmados: hashes, proveniência e budget fornecem conceitos úteis; não comprovam API de invalidação ou suporte multiprocesso. Chave deve incluir identidade/projeto/usuário, escopo e revisão de permissões, filtros, consulta, k, budget, versão de política/formato e revisões aplicáveis dos dados. Mudança de autorização precisa invalidar ou produzir miss, mesmo para consulta idêntica.

Começar com invalidação conservadora por projeto a cada mutação relevante. TTL limita residência e **não garante freshness**; limites de RAM e eventual LRU dependem da medição. Revalidar a geração/revisão antes de usar o resultado; versão ou escopo indefinidos resultam em cache miss, com recuperação normal autorizada. Antes de habilitar, definir como leitura e uso permanecem coerentes com mutações concorrentes. Multiprocessos e alterações externas são desconhecidos: sem fonte confiável de versão e protocolo de coerência, não habilitar reuse nesses caminhos. Esse desenho reduz riscos delimitados, sem prometer zero stale universal.

## 6. Melhorias recomendadas

A matriz é o detalhamento acionável da direção única EF; os IDs T125 identificam aprofundamentos, não novos itens independentes. P1 significa alto retorno potencial; P2, estrutural; P3, pesquisa. Nenhuma intervenção recebe P0 crítico nesta proposta. Impacto é potencial qualitativo, não resultado medido; esforço e risco são inferências preliminares.

| ID / vínculo / prioridade | Objetivo, fundamento e escolha | Impacto / esforço / risco; confiança | Ordem e pré-requisitos | Aceite, benchmark, risco e rollback |
| --- | --- | --- | --- | --- |
| T125-01 / EF-01 / P1 | Tornar fronteiras observáveis: instrução, base, histórico, recuperação, envelope; separar hashes/bytes/relógios de usage bruto. Preferir captura mínima à inferência de piso do host | Alto / médio / baixo; alta na necessidade, ganho desconhecido | Primeira ação futura; escopo público dev e reviewer; interface de captura desconhecida | Offline: componentes conciliáveis e unknowns explícitos, sem dupla contagem nem exposição indevida. Risco de overhead: medir e desligar captura, preservando artefatos sanitizados |
| T125-02 / EF-02 / P1 | Testar sobreposição base/recuperação por hash e faixas; preferir comparação determinística a dedupe semântico | Alto / baixo / baixo; média na hipótese | Após 01; fontes autorizadas e cobertura esperada de dev novo | Offline: relatório reproduzível de redundância removível e proveniência. Se ausente, rejeitar hipótese; rollback é encerrar investigação sem mudança de runtime |
| T125-03 / EF-03 / P1 | Reduzir repetição confirmada contra base; avaliar compact-v1 existente e dedupe em ablações separadas, sem confundir com dedupe108 entre memórias | Alto / médio / médio; média, condicional a 02 | Após 02; conteúdo realmente enviado pelo host identificável, contrato de montagem ainda a esclarecer | Bytes menores com fatos/citações preservados; usage real só em etapa autorizada. Risco de remover distinção relevante: retornar ao envelope/política anterior e manter proveniência |
| T125-04 / EF-04 / P1 | Avaliar gating com balanced-v1 antes de criar regras; impedir inclusões inúteis e falsas abstenções | Médio / médio / médio; média | Após 01/02; positivos/negativos dev e tolerâncias prévias | Medir recall, falsa inclusão/abstenção, bytes e qualidade; nenhuma perda obrigatória no gate real. Rollback para política anterior/legacy, sem presumir mecanismo de toggle |
| T125-05 / EF-05 / P2 | Ajustar uma variável de budget, ranking ou chunk por vez antes de recuperação progressiva/hierárquica | Médio / médio / médio; baixa antes dos gates anteriores | Após 03/04; custo por etapa e lacunas de cobertura medidos | Melhor cobertura por byte com busca/end-to-end aceitáveis e gate factual; descartar ajuste instável, restaurar configuração congelada |
| T125-06 / EF-06 / P2 | Avaliar repetição, histórico genuíno e reuse incremental; cache exato somente se custo evitado justificar. Resumos e exportação candidata são opções posteriores, não pacote obrigatório | Médio / médio / alto; baixa | Instrumentação madura, protocolo de revisão/permissões e nova especificação; interfaces desconhecidas | Offline: equivalência, invalidação/isolamento e custo acumulado; depois plano H próprio. Risco stale/conflito: desabilitar reuse e invalidar entradas, voltar à recuperação autorizada |
| T125-07 / EF-07 / P3 | Manter semântico/híbrido/rerank e cache tuning em pesquisa, contra baseline determinístico | Médio / alto / alto; baixa | Só abrir com falha lexical ou cache atribuível e decisão do supervisor | Benefício isolado além do custo e falso hit dentro de critério prévio, nunca sobre fatos obrigatórios. Se não demonstrado, permanecer adiado; rollback sem camada extra |

**Economia e ganho de latência de todas as intervenções: ainda não estimáveis.** Os percentuais históricos da seção 3 são resultados de recortes específicos e não estimativas destas intervenções. EF-00 permanece consolidação documental; esta entrega não o reabre. [Backlog ordenado](docs/benchmarks/v03/plano-eficiencia.md#backlog-ordenado).

## 7. Estratégia de otimização

Aplicar a sequência observar → testar hipótese offline → comparar uma intervenção → revisar → solicitar experimento limitado. O alvo é contexto necessário com qualidade, e o objetivo de custo deve incluir busca, montagem e host, não apenas bytes. Não descontar setup invisível: ingestão/indexação/setup/cleanup separados e custo total amortizado por N tarefas reais declarado; não assumir reutilização infinita nem somar recuperação duas vezes ao end-to-end.

**Inferência técnica:** remover trabalho repetido pode ter retorno maior do que acrescentar índices ou cache, mas a ordem depende de medições. Serialização e varredura de matches FTS sem LIMIT são candidatos de medição, não gargalos confirmados. Respeitar o hard budget existente, medir compact-v1 e só depois considerar orçamento adaptativo. Deduplicação semântica, resumo e cache semântico precisam provar que não confundem versões, condições, negações ou fontes conflitantes.

A compatibilidade do host é uma fronteira: otimizar apenas conteúdo e ordem do envelope sob controle demonstrável do Mimir. Usage real, subset cached e custo monetário são campos distintos; não substituir uns pelos outros. [Diagnóstico](docs/benchmarks/v03/plano-eficiencia.md#diagnóstico-a-resolver-primeiro) e [Comparação futura](docs/benchmarks/v03/plano-eficiencia.md#comparação-futura-mesmo-problema-e-acesso-equivalente).

## 8. Roadmap de implementação

| Etapa | Entrega futura e condição de avanço |
| --- | --- |
| Agora, documental | Proposta125 e revisão126 pendente; zero implementação e zero chamadas. Plano operacional preservado |
| Diagnóstico offline | Supervisor delimita EF-01/02 com fontes públicas dev autorizadas, captura mínima, análise de sobreposição e reviewer antes de uso real |
| Intervenção offline | Escolher EF-03 ou EF-04 conforme evidência; provar cobertura/proveniência, medir overhead e congelar candidato. Não implementar todas as linhas da matriz |
| Piloto condicional | Só após gates e autorização específica: dois dev novos, A completo/B substituição/D baseline forte, uma repetição, máximo seis chamadas; manifesto viável offline |
| Expansão condicionada | EF-05 e depois EF-06 apenas se resultados justificarem; histórico, outros hosts e evaluation nova exigem planos próprios. EF-07 continua adiado |

O piloto proposto preserva 90s/chamada, 12min globais incluindo preparação/recuperação, retry0, sem warmup pago/fallback/descoberta, até 32.000 bytes de contexto e 64.000 bytes de resposta por tentativa, limite verbal comum congelado. Timeout/falha consome tentativa; restantes not_run ao atingir teto. Sem E/H no primeiro lote; não repetir54. Quota desconhecida; teto não é autorização nem garantia de disponibilidade. [Escada de gasto e gates](docs/benchmarks/v03/plano-eficiencia.md#escada-de-gasto-e-gates).

## 9. Plano de validação

**Agora:** apenas consistência documental. A matriz abaixo é desenho futuro, não autorização para executar todos os braços.

Para caching, separar nomes dos braços do desenho A/B/D do piloto: **cache-A** sem cache; **cache-B** cache exato; **cache-C** organização determinística do envelope controlável; **cache-D** cache semântico somente com justificativa; **cache-E** combinação somente após avaliação isolada. Manter fontes, revisões, consulta, política, k, budget e escopo equivalentes. Não confundir organização de envelope com hit de Prompt Caching observado.

Offline, declarar n por condição e distribuição de consultas, hits/misses, latências p50/p95 com n correspondente, RAM, evictions e custo de invalidação. Testar update/delete, mudança de filtros/política/budget e permissão, escopos cruzados, conflitos, revisão indefinida, mutações concorrentes e, se aplicável, multiprocessos. Taxa stale = resultados reutilizados obsoletos / resultados reutilizados verificados, publicando numerador e denominador; denominador zero é N_A. Equivalência e cobertura frente à recuperação sem cache são obrigatórias. Cold/warm local só quando efetivamente controlável; cache do host pode permanecer desconhecido. Não extrapolar ausência de stale no conjunto para garantia universal.

Prompt Caching só é avaliado se observável: guardar input e subset cached separadamente, nunca somar cache novamente ao input. Custo monetário permanece unknown sem exposição suficiente. Medir overhead de lookup/revalidação e custo acumulado com setup antes de aceitar cache. Se não houver repetição suficiente ou o custo líquido não melhorar, decisão válida é não adicionar.

No experimento real futuro, seguir o [desenho comum](docs/benchmarks/v03/plano-eficiencia.md#comparação-futura-mesmo-problema-e-acesso-equivalente): seis dev novos propostos cobrindo categorias, três evaluation novos independentes custodiados por avaliador distinto, sem acesso do implementador; piloto usa apenas dois dev. A completo, B substituição e D baseline forte têm mesmo problema/pool/orçamento; E aditivo separado e H genuíno nos turnos1/3/6 com custo acumulado, em planos posteriores. Holdout consumido não volta intacto.

Congelar configuração, fontes/hashes, ordem e critérios antes de evaluation. Gate operacional: zero perda de fatos obrigatórios ou citações válidas frente ao baseline forte, zero invenção e zero abstenção indevida, com limite verbal comum. Medir end-to-end, busca, bytes, usage bruto, falhas e cobertura sem esconder ausências; backend/modelo efetivo e TTFT desconhecidos quando não observados. AG continua nativo separado. Economia percentual só para mesma unidade e A>0: `(1 − B/A) × 100`; A=0 implica N_A. Publicar absolutos, deltas pareados e razões com denominadores; repetição não cria novo caso. Ganho de contexto só é aceito junto à qualidade e ao custo end-to-end.

## 10. Questões para o CAO

As perguntas fecham lacunas para tarefas futuras; não demandam nova auditoria nesta entrega.

1. Que parcelas de instrução/base/histórico/envelope o Mimir e o host realmente controlam e expõem? Qual contrato permite capturá-las sem inferir tokens do modelo?
2. Quais fontes públicas dev novas estão autorizadas para EF-01/02 e quem custodia evaluation independente?
3. Há cache interno de recuperação ou contexto? Qual seu escopo, chave, revisão, invalidação, custo e observabilidade? Existe mecanismo de cache do host observável e controlável?
4. Como identidade, projeto, usuário e permissões são representados? Há revisão confiável para mutações externas e coordenação entre processos, inclusive entre revalidação e uso?
5. Onde se mede recuperação, serialização, montagem, ingestão e indexação? Que repetição real existe por tarefa/sessão e qual custo acumulado interessa otimizar?
6. Como compact-v1 e balanced-v1 são escolhidos no fluxo autorizado? É possível identificar conteúdo já enviado pelo host para dedupe sem remover proveniência?
7. Quais necessidades reais de histórico, conflito, stale e escala justificariam EF-05/06? Há interface de ingestão apta a receber candidatos estruturados e autoridade definida para validá-los?
8. Quem revisará126 e quem aprovará o escopo offline seguinte? Para eventual piloto, quais disponibilidade, autorização e manifesto confirmam viabilidade dentro do teto proposto?

## 11. HANDOFF PARA CAO

**Ação solicitada ao supervisor:** encaminhar esta proposta à revisão126; depois delimitar diagnóstico offline EF-01/02 como próximo tópico, com fontes e fronteiras de captura explícitas. Esta entrega não pede liberação de piloto nem adiciona cache.

Priorizar T125-01 → T125-02 → T125-03 condicional, conforme dependências e critérios na seção 6. Evitar comparar 30,33%/39,58% com +2,93% como evolução da mesma métrica, subtrair piso inferido do host, usar history0 como histórico real, prometer economia/cache e abrir complexidade sem diagnóstico. Diante de sobreposição ausente, rejeitar a hipótese e considerar EF-04; diante de repetição/custo local insuficientes, manter decisão de não adicionar cache.

Lacunas principais: montagem observável, tokenização real, custo/host, existência de cache interno e coerência de revisões/permissões. Nenhuma foi preenchida consultando código ou referências secundárias. Plano operacional EF-00–07 permanece a direção única; toda implementação, revisão de código e execução futura terá escopo próprio. **Realizado nesta tarefa: documentação, zero código e zero chamadas de benchmark.**
